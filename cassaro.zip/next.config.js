// next.config.js
module.exports = {
  i18n: {
    locales: ['es', 'pt', 'en'],
    defaultLocale: 'en',
  },
}